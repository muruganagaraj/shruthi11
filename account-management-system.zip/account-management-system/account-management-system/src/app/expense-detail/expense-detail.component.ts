import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AddExpenseDetailComponent } from 'app/add-expense-detail/add-expense-detail.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ExpenseDetail } from 'model/expenseModel';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { TextPairHelperService } from '../services/text-pair-helper.service';
import { ViewModel, ItemViewmodel } from './expense-detail.viewmodel';

@Component({
  selector: 'app-expense-detail',
  templateUrl: './expense-detail.component.html',
  styleUrls: ['./expense-detail.component.scss']
})
export class ExpenseDetailComponent implements OnInit {
  expenseForm: FormGroup;
  isGSTRequired: boolean;
  buyerList: TextPair[] = [];
  isExpensive: boolean = false;
  vm: ViewModel[] = [];
  constructor(public dialog: MatDialog, private formBuilder: FormBuilder,
    private http: HttpClient,
    private textPairHelperService: TextPairHelperService) { }
  ngOnInit() {
    this.isGSTRequired = false;
    this.getBuyerList();
  }
  getBuyerList(): any {
    const endpoint: string = 'https://cfztsaiwb1.execute-api.us-east-1.amazonaws.com/default/EDU_B_GETAll';
    this.http.get(endpoint).subscribe((item: any) => {
      this.buyerList = this.textPairHelperService.createBuyerTextPair(item);
    });
  }
  getExpensiveData(value: any): void {
    console.log('make api call');
    const endpoint: string = 'https://73hm04j8hh.execute-api.us-east-1.amazonaws.com/default/EDU_Expense_Get';
    this.http.get(endpoint).subscribe((item: any) => {
      if (item.length > 0) {
        let data: any[] = item.filter(x => x.BuyerId === value);
        if (data.length > 0) {
          this.isExpensive = true;
          this.vm = this.getdata(data);
        } else {
          this.isExpensive = false;
          alert('no data found for the buyer, please choose differenct buyer.');
        }
      } else {
        this.isExpensive = false;
        alert('no data found for the buyer, please choose differenct buyer.');
      }
    });
  }


  getdata(expItem: any[]): ViewModel[] {
    return (expItem || []).map((item: any) => <ViewModel>{
      ExpenseId: item.ExpenseId,
      BuyerId: item.BuyerId,
      ExpenseDate: item.ExpenseDate,
      TotalItemAmount: item.TotalItemAmount,
      IsGSTRequired: item.IsGSTRequired,
      GST: item.GST,
      TotalAmountWithGST: item.TotalAmountWithGST,
      Discount: item.Discount,
      FinalAmount: item.FinalAmount,
      items: this.getItemData(item.Items)
    });
  }

  getItemData(list: any[]): ItemViewmodel[] {
    return (list || []).map((item: any) => <ItemViewmodel>{
      ExpenseId: item.ExpenseId,
      ItemId: item.ItemId,
      ItemCode: item.ItemCode,
      ItemName: item.ItemName,
      Quantity: item.Quantity,
      Amount: item.Amount
    });
  }


  openDialog(): void {
    debugger;
    const dialogRef = this.dialog.open(AddExpenseDetailComponent, {
      height: "auto",
      width: "auto",
      data: { undefined }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  onChange(value: any): void {
    this.getExpensiveData(value);
  }

  onSubmit() {

  }
}
