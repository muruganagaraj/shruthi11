export interface ViewModel {
    ExpenseId?: number;
    BuyerId?: number;
    ExpenseDate?: Date;
    TotalItemAmount?: number;
    IsGSTRequired?: boolean;
    GST?: number;
    TotalAmountWithGST?: number;
    Discount?: number;
    FinalAmount?: number;
    items?: ItemViewmodel[];
}
export interface ItemViewmodel {
    ExpenseId?: number;
    ItemId?: number;
    ItemCode?: string;
    ItemName?: string;
    Quantity?: number;
    Amount?: number;
}