export interface ViewModel {
    BuyerId?: number;
    BuyerCode?: string;
    GSTId?: number;
    Name?: string;
    Address?: string;
    ContactNo?: string;
    GSTCode?: string;
}