export interface Viewmodel {
    BuyerId?: number;
    BuyerCode?: string;
    GSTId?: string;
    Name?: string;
    Address?: string;
    ContactNo?: string;
}